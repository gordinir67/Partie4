import { expect } from '@jest/globals';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { FormComponent } from './form.component';
import { SessionApiService } from '../../../../core/service/session-api.service';
import { SessionService } from '../../../../core/service/session.service';
import { TeacherService } from '../../../../core/service/teacher.service';
import { MatSnackBar } from '@angular/material/snack-bar';

describe('FormComponent (integration)', () => {
  const routerMock = { navigate: jest.fn(), url: '/sessions/create' } as any;
  const routeMock = {
    snapshot: { paramMap: { get: (_: string) => '10' } },
  } as any;

  const snackBarMock = { open: jest.fn() };

  const sessionApiMock = {
    detail: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  };

  const teacherServiceMock = {
    all: jest.fn(),
  };

  beforeEach(async () => {
    jest.clearAllMocks();

    teacherServiceMock.all.mockReturnValue(of([]));
    sessionApiMock.detail.mockReturnValue(
      of({ id: 10, name: 'S', date: '2026-01-01', teacher_id: 1, description: 'D', users: [] } as any)
    );
    sessionApiMock.create.mockReturnValue(of({} as any));
    sessionApiMock.update.mockReturnValue(of({} as any));

    await TestBed.configureTestingModule({
      imports: [FormComponent],
      providers: [
        { provide: Router, useValue: routerMock },
        { provide: ActivatedRoute, useValue: routeMock },
        { provide: MatSnackBar, useValue: snackBarMock },
        { provide: SessionApiService, useValue: sessionApiMock },
        { provide: TeacherService, useValue: teacherServiceMock },
      ],
    }).compileComponents();
  });

  it('should redirect non-admin to /sessions', () => {
    TestBed.overrideProvider(SessionService, {
      useValue: { sessionInformation: { id: 1, admin: false } },
    });

    const fixture = TestBed.createComponent(FormComponent);
    fixture.detectChanges(); // ngOnInit

    expect(routerMock.navigate).toHaveBeenCalledWith(['/sessions']);
  });

  it('should create session when url is create', () => {
    TestBed.overrideProvider(SessionService, {
      useValue: { sessionInformation: { id: 1, admin: true } },
    });
    routerMock.url = '/sessions/create';

    const fixture = TestBed.createComponent(FormComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges(); // ngOnInit -> initForm()

    component.sessionForm!.setValue({
      name: 'New',
      date: '2026-01-05',
      teacher_id: 1,
      description: 'Desc',
    });

    component.submit();

    expect(sessionApiMock.create).toHaveBeenCalled();
    expect(snackBarMock.open).toHaveBeenCalledWith('Session created !', 'Close', { duration: 3000 });
    expect(routerMock.navigate).toHaveBeenCalledWith(['sessions']);
  });

  it('should update session when url includes update', () => {
    TestBed.overrideProvider(SessionService, {
      useValue: { sessionInformation: { id: 1, admin: true } },
    });
    routerMock.url = '/sessions/update/10';

    const fixture = TestBed.createComponent(FormComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges(); // ngOnInit -> detail(id) -> initForm(session)

    component.sessionForm!.setValue({
      name: 'Updated',
      date: '2026-01-06',
      teacher_id: 2,
      description: 'Desc2',
    });

    component.submit();

    expect(sessionApiMock.update).toHaveBeenCalledWith('10', expect.any(Object));
    expect(snackBarMock.open).toHaveBeenCalledWith('Session updated !', 'Close', { duration: 3000 });
    expect(routerMock.navigate).toHaveBeenCalledWith(['sessions']);
  });
});
