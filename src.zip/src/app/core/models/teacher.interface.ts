export interface Teacher {
  id: number;
  lastName: string;
  firstName: string;
  createdAt: Date;
  updatedAt: Date;
}
