export interface RegisterRequest {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
}
